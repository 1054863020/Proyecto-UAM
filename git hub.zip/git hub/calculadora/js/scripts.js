function Tablas() {
   
    for (var i= 0; i < 10; i++) {
      var A = 1;
      var R = A* i;
      console.log("Tabla del 1" + R);  
    }
};




function multi() {
   
  
    var num1 =document.getElementById("num1").value;
    var numReal= parseInt(num1);

    var num2 =document.getElementById("num2").value;
    var numReal2= parseInt(num2);
    
    var Res = numReal * numReal2;

    console.log("resultado: " + Res);
      
      
      alert("el resultado es:" + Res );

    }





function divi() {
   

    var num1 =document.getElementById("num1").value;
    var numReal= parseInt(num1);

    var num2 =document.getElementById("num2").value;
    var numReal2= parseInt(num2);
    
    var Res = numReal / numReal2;

    console.log("resultado: " + Res);
      
      
      alert("el resultado es:" + Res );

    }





function suma() {
   
    var num1 =document.getElementById("num1").value;
    var numReal= parseInt(num1);

    var num2 =document.getElementById("num2").value;
    var numReal2= parseInt(num2);
    
    var Res = numReal + numReal2;

    console.log("resultado: " + Res);
      // parseint
      
      alert("el resultado es:" + Res );

    }





    function resta() {
   
        var num1 =document.getElementById("num1").value;
        var numReal= parseInt(num1);
    
        var num2 =document.getElementById("num2").value;
        var numReal2= parseInt(num2);
        
        var Res = numReal - numReal2;
    
        console.log("resultado: " + Res);
          
          
          alert("el resultado es:" + Res );
    
        }




        function ce () {
           var num1 = document.getElementById("num1").value = "";
           var num2 = document.getElementById("num2").value = "";
        }